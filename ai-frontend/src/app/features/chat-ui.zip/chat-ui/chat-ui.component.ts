import {
  Component,
  ElementRef,
  ViewChild,
  AfterViewChecked,
  ChangeDetectorRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AiService } from '../../core/services/ai.service';

interface Message {
  id: number;
  text: string;
  isUser: boolean;
  timestamp: Date;
  isTyping?: boolean;
}

@Component({
  selector: 'app-chat-ui',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chat-ui.component.html',
  styleUrls: ['./chat-ui.component.css'],
})
export class ChatUiComponent implements AfterViewChecked {
  @ViewChild('chatMessagesContainer') private messagesContainer!: ElementRef;

  messages: Message[] = [];
  currentQuestion = '';
  isLoading = false;
  private messageId = 0;

  constructor(
    private aiService: AiService,
    private cdr: ChangeDetectorRef,
  ) {
    this.addBotMessage(
      "Hello! I'm your AI assistant. Ask me anything about programming, technology, or general knowledge.",
    );
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
    this.addCopyButtonsToCodeBlocks();
  }

  sendMessage(): void {
    if (!this.currentQuestion.trim() || this.isLoading) return;

    const userMessage = this.currentQuestion.trim();
    this.addUserMessage(userMessage);
    this.currentQuestion = '';
    this.isLoading = true;

    const typingId = this.addTypingIndicator();

    this.aiService.askQuestion(userMessage).subscribe({
      next: (response: any) => {
        this.removeTypingIndicator(typingId);
        const formattedResponse = this.convertMarkdownToHtml(
          response.answer ||
            "I received your message but couldn't generate a proper response.",
        );
        this.addBotMessage(formattedResponse);
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: (error) => {
        this.removeTypingIndicator(typingId);
        this.addBotMessage(
          'Sorry, I encountered an error. Please check your connection and try again.',
        );
        console.error('API Error:', error);
        this.isLoading = false;
        this.cdr.detectChanges();
      },
    });
  }

  private convertMarkdownToHtml(markdown: string): string {
    let html = markdown;

    // 1. Handle code blocks with language support
    html = html.replace(
      /```(\w+)?\n([\s\S]*?)```/g,
      (match, language, code) => {
        const languageName = language || 'plaintext';
        const escapedCode = this.escapeHtml(code.trim());
        return `
        <div class="code-block-wrapper">
          <div class="code-header">
            <span class="code-language">${languageName}</span>
            <button class="copy-code-btn" data-code="${this.escapeHtmlAttr(escapedCode)}">
              <svg class="copy-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 1H4C2.9 1 2 1.9 2 3V17H4V3H16V1ZM19 5H8C6.9 5 6 5.9 6 7V21C6 22.1 6.9 23 8 23H19C20.1 23 21 22.1 21 21V7C21 5.9 20.1 5 19 5ZM19 21H8V7H19V21Z" fill="currentColor"/>
              </svg>
              <span>Copy</span>
            </button>
          </div>
          <pre><code class="language-${languageName}">${escapedCode}</code></pre>
        </div>
      `;
      },
    );

    // 2. Handle inline code
    html = html.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');

    // 3. Handle headers
    html = html.replace(/^### (.*?)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.*?)$/gm, '<h2>$1</h2>');
    html = html.replace(/^# (.*?)$/gm, '<h1>$1</h1>');

    // 4. Handle bold and italic
    html = html.replace(/\*\*\*(.*?)\*\*\*/g, '<strong><em>$1</em></strong>');
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

    // 5. Handle tables
    const tableRegex = /\|(.+)\|\n\|[-:\s|]+\|\n((?:\|.+\|\n?)+)/gm;
    html = html.replace(tableRegex, (match, headerRow, bodyRows) => {
      const headers = headerRow
        .split('|')
        .filter((cell: string) => cell.trim());
      const headerHtml = `<tr>${headers.map((h: string) => `<th>${h.trim()}</th>`).join('')}</tr>`;

      const bodyHtml = bodyRows
        .trim()
        .split('\n')
        .map((row: string) => {
          const cells = row.split('|').filter((cell: string) => cell.trim());
          return `<tr>${cells.map((c) => `<td>${c.trim()}</td>`).join('')}</tr>`;
        })
        .join('');

      return `<div class="table-wrapper"><table>${headerHtml}${bodyHtml}</table></div>`;
    });

    // 6. Handle unordered lists
    let inList = false;
    const lines = html.split('\n');
    const processedLines = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.match(/^[\*\-] /)) {
        if (!inList) {
          processedLines.push('<ul class="custom-list">');
          inList = true;
        }
        processedLines.push(`<li>${line.substring(2)}</li>`);
      } else {
        if (inList) {
          processedLines.push('</ul>');
          inList = false;
        }
        processedLines.push(line);
      }
    }
    if (inList) {
      processedLines.push('</ul>');
    }
    html = processedLines.join('\n');

    // 7. Handle ordered lists
    inList = false;
    const lines2 = html.split('\n');
    const processedLines2 = [];

    for (let i = 0; i < lines2.length; i++) {
      const line = lines2[i];
      if (line.match(/^\d+\. /)) {
        if (!inList) {
          processedLines2.push('<ol>');
          inList = true;
        }
        processedLines2.push(
          `<li>${line.substring(line.indexOf('.') + 2)}</li>`,
        );
      } else {
        if (inList) {
          processedLines2.push('</ol>');
          inList = false;
        }
        processedLines2.push(line);
      }
    }
    if (inList) {
      processedLines2.push('</ol>');
    }
    html = processedLines2.join('\n');

    // 8. Handle horizontal rules
    html = html.replace(/^---$/gm, '<hr>');

    // 9. Handle blockquotes
    html = html.replace(/^> (.*?)$/gm, '<blockquote>$1</blockquote>');

    // 10. Handle line breaks and paragraphs
    const paragraphs = html.split('\n\n');
    html = paragraphs
      .map((para) => {
        para = para.trim();
        if (!para) return '';
        if (para.startsWith('<') && !para.startsWith('<p>')) {
          return para;
        }
        return `<p>${para.replace(/\n/g, '<br>')}</p>`;
      })
      .join('');

    return html;
  }

  private escapeHtmlAttr(text: string): string {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  private addCopyButtonsToCodeBlocks(): void {
    // Find all code block wrappers in the messages container
    if (!this.messagesContainer || !this.messagesContainer.nativeElement) {
      return;
    }

    const codeBlocks = this.messagesContainer.nativeElement.querySelectorAll(
      '.code-block-wrapper',
    );

    codeBlocks.forEach((wrapper: HTMLElement) => {
      const copyButton = wrapper.querySelector('.copy-code-btn');
      if (copyButton && !copyButton.hasAttribute('data-initialized')) {
        copyButton.setAttribute('data-initialized', 'true');

        copyButton.addEventListener('click', async (e) => {
          e.preventDefault();
          e.stopPropagation();

          const code = copyButton.getAttribute('data-code');
          if (code) {
            const decodedCode = this.decodeHtmlEntities(code);
            await this.copyToClipboard(decodedCode, copyButton as HTMLElement);
          }
        });
      }
    });
  }

  private decodeHtmlEntities(text: string): string {
    const textarea = document.createElement('textarea');
    textarea.innerHTML = text;
    return textarea.value;
  }

  private async copyToClipboard(
    text: string,
    button: HTMLElement,
  ): Promise<void> {
    try {
      await navigator.clipboard.writeText(text);

      // Store original content
      const originalHtml = button.innerHTML;

      // Update button to show success
      button.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" fill="currentColor"/>
        </svg>
        <span>Copied!</span>
      `;
      button.classList.add('copied');

      // Add a temporary tooltip
      const tooltip = document.createElement('div');
      tooltip.className = 'copy-tooltip';
      tooltip.textContent = 'Copied!';
      tooltip.style.position = 'absolute';
      tooltip.style.bottom = '100%';
      tooltip.style.right = '0';
      tooltip.style.marginBottom = '5px';
      tooltip.style.padding = '4px 8px';
      tooltip.style.background = '#10a37f';
      tooltip.style.color = 'white';
      tooltip.style.borderRadius = '4px';
      tooltip.style.fontSize = '12px';
      tooltip.style.whiteSpace = 'nowrap';
      tooltip.style.zIndex = '1000';

      const parentElement = button.parentElement;
      if (parentElement) {
        parentElement.style.position = 'relative';
        parentElement.appendChild(tooltip);
      }

      setTimeout(() => {
        button.innerHTML = originalHtml;
        button.classList.remove('copied');
        if (tooltip.parentElement) {
          tooltip.remove();
        }
        if (parentElement) {
          parentElement.style.position = '';
        }
      }, 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
      // Show error feedback
      const originalHtml = button.innerHTML;
      button.innerHTML = `<span>❌ Error</span>`;
      setTimeout(() => {
        button.innerHTML = originalHtml;
      }, 2000);
    }
  }

  private escapeHtml(text: string): string {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  private addUserMessage(text: string): void {
    this.messages.push({
      id: this.messageId++,
      text: text,
      isUser: true,
      timestamp: new Date(),
    });
  }

  private addBotMessage(text: string): void {
    this.messages.push({
      id: this.messageId++,
      text: text,
      isUser: false,
      timestamp: new Date(),
    });
  }

  private addTypingIndicator(): number {
    const typingId = this.messageId++;
    const typingMessage: Message = {
      id: typingId,
      text: '...',
      isUser: false,
      timestamp: new Date(),
      isTyping: true,
    };
    this.messages.push(typingMessage);
    return typingId;
  }

  private removeTypingIndicator(id: number): void {
    const index = this.messages.findIndex((m) => m.id === id);
    if (index !== -1) {
      this.messages.splice(index, 1);
    }
  }

  private scrollToBottom(): void {
    try {
      if (this.messagesContainer && this.messagesContainer.nativeElement) {
        this.messagesContainer.nativeElement.scrollTop =
          this.messagesContainer.nativeElement.scrollHeight;
      }
    } catch (err) {}
  }

  formatTime(date: Date): string {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
}
